
import numpy as np
import pandas as pd
import warnings
from tqdm import tqdm
from untrade.client import Client
import ta
from ta.trend import ADXIndicator
from ta.volume import OnBalanceVolumeIndicator
from ta.trend import EMAIndicator
from ta.volatility import BollingerBands
import uuid
import os
warnings.filterwarnings("ignore")

# ## Untrade backtesting script
from untrade.client import Client
from pprint import pprint

def perform_backtest_large_csv(csv_file_path):
     client = Client()
     file_id = str(uuid.uuid4())
     chunk_size = 90 * 1024 * 1024
     total_size = os.path.getsize(csv_file_path)
     total_chunks = (total_size + chunk_size - 1) // chunk_size
     chunk_number = 0
     if total_size <= chunk_size:
         total_chunks = 1
         # Normal Backtest
         result = client.backtest(
             file_path=csv_file_path,
             leverage=1,
             jupyter_id="Team22_Zelta_HPPS",
             # result_type="Q",
         )
         for value in result:
             print(value)

         return result

     with open(csv_file_path, "rb") as f:
         while True:
             chunk_data = f.read(chunk_size)
             if not chunk_data:
                 break
             chunk_file_path = f"/tmp/{file_id}_chunk_{chunk_number}.csv"
             with open(chunk_file_path, "wb") as chunk_file:
                 chunk_file.write(chunk_data)

             # Large CSV Backtest
             result = client.backtest(
                 file_path=chunk_file_path,
                 leverage=1,
                 jupyter_id="Team22_Zelta_HPPS",
                 file_id=file_id,
                 chunk_number=chunk_number,
                 total_chunks=total_chunks,
                 # result_type="Q",
             )

             for value in result:
                 print(value)

             os.remove(chunk_file_path)

             chunk_number += 1

     return result

def perform_backtest(csv_file_path, type=None):
    """
    Perform backtesting using the untrade SDK.

    Parameters:
    - csv_file_path (str): Path to the CSV file containing historical price data and signals.
    - type: type of result

    Returns:
    - result (generator): Result is a generator object that can be iterated over to get the backtest results.
    """
    # Create an instance of the untrade client
    client = Client()

    if type is not None:
    # Perform backtest using the provided CSV file path
        result = client.backtest(
            file_path=csv_file_path,
            leverage=1,  # Adjust leverage as needed
            jupyter_id="Team22_Zelta_HPPS",  # the one you use to login to jupyter.untrade.io
            result_type=type
        )

    else:
        result = client.backtest(
            file_path=csv_file_path,
            leverage=1,  # Adjust leverage as needed
            jupyter_id="Team22_Zelta_HPPS",  # the one you use to login to jupyter.untrade.io
        )

    for i in result:
        print(i)
    return result


##############################################################################################################################################
# INDICATOR CALCULATION FUNCTIONS 
# START
def calculate_supertrend(data, atr_period=14, multiplier=1.5):
    """
    Calculates the Supertrend indicator.
    """
    data['atr'] = data['high'].rolling(window=atr_period).max() - data['low'].rolling(window=atr_period).min()
    data['basic_upper_band'] = (data['high'] + data['low']) / 2 + multiplier * data['atr']
    data['basic_lower_band'] = (data['high'] + data['low']) / 2 - multiplier * data['atr']

    # Initialize Supertrend
    data['final_upper_band'] = data['basic_upper_band']
    data['final_lower_band'] = data['basic_lower_band']
    data['supertrend'] = 0

    for i in range(1, len(data)):
        if data['close'][i - 1] > data['final_upper_band'][i - 1]:
            data['final_upper_band'][i] = min(data['basic_upper_band'][i], data['final_upper_band'][i - 1])
        if data['close'][i - 1] < data['final_lower_band'][i - 1]:
            data['final_lower_band'][i] = max(data['basic_lower_band'][i], data['final_lower_band'][i - 1])

        if data['close'][i] > data['final_upper_band'][i - 1]:
            data['supertrend'][i] = data['final_lower_band'][i]
        else:
            data['supertrend'][i] = data['final_upper_band'][i]

    # Create Supertrend signal (True for uptrend)
    data['supertrend_signal'] = data['close'] > data['supertrend']
    return data

def calculate_entropy(series, window=14):
    """
    Calculate the Shannon entropy of a given volume series in a rolling window.
    """
    # Bin the data into 10 discrete values
    hist, bin_edges = np.histogram(series, bins=10, density=True)
    hist = hist[hist > 0]  # Remove zero values to avoid log(0)
    # Calculate the Shannon entropy
    entropy = -np.sum(hist * np.log2(hist))
    return entropy

# Function to calculate entropy and add it as a new column to a CSV
def add_entropy_to_csv(df, window=30):
    # Check if the necessary columns are in the dataframe (OHLC + volume)
    if 'log_returns' not in df.columns:
        raise ValueError("CSV file must contain a 'volume' column.")
    
    # Apply entropy calculation in a rolling window
    df['log_returns_entropy'] = df['log_returns'].rolling(window=window).apply(lambda x: calculate_entropy(x, window), raw=False)
    return df
  # Replace with your actual CSV file path

def calculate_dema(df, column='close', window=20):
    # Calculate the first EMA
    ema1 = df[column].ewm(span=window, adjust=False).mean()
    # Calculate the second EMA on the first EMA
    ema2 = ema1.ewm(span=window, adjust=False).mean()
    # Calculate DEMA
    df['DEMA'] = 2 * ema1 - ema2
    return df

# INDICATOR Methods END
#######################################################################################################################################
def process_data(data):
     """
     Process the input data and return a dataframe with all the necessary indicators and data for making signals.

     Parameters:
     data (pandas.DataFrame): The input data to be processed.

     Returns:
     pandas.DataFrame: The processed dataframe with all the necessary indicators and data.
     """
     stoch = ta.momentum.StochasticOscillator(
     high=data['high'],
     low=data['low'],
     close=data['close'],
     window=14,         # Window for %K (typically 14)
     smooth_window=3    # Window for %D (typically 3)
     )
     data['ema_12'] = data['close'].ewm(span=12, adjust=False).mean()  # 12-period EMA
     data['ema_26'] = data['close'].ewm(span=26, adjust=False).mean()  # 26-period EMA
     obv_indicator = OnBalanceVolumeIndicator(close=data['close'], volume=data['volume'])
     data['obv'] = obv_indicator.on_balance_volume()
     short_ema_length = 20
     ema_obv = EMAIndicator(close=data['obv'], window=short_ema_length)
     data['obv_ema'] = ema_obv.ema_indicator()
     data['obv_osc'] = data['obv'] - data['obv_ema']
     bb = BollingerBands(close=data['close'], window=20, window_dev=2)
     data['bb_lower'] = bb.bollinger_lband()
     data['bb_upper'] = bb.bollinger_hband()
     data['bbw'] = (bb.bollinger_hband() - bb.bollinger_lband()) / bb.bollinger_mavg()
     bbw_sma_fast = data['bbw'].rolling(window=20).mean()
     bbw_sma_slow = data['bbw'].rolling(window=100).mean()
     bbw_std = data['bbw'].rolling(window=20).std()
     data['vli_fast'] = bbw_sma_fast
     data['vli_slow'] = bbw_sma_slow
     data['log_returns'] = np.log(data['close'] / data['close'].shift(1))
     data = add_entropy_to_csv(data, window=14)
     data['entropy_threshold'] = data['log_returns_entropy'].rolling(window=14).mean()
     # Calculate EMAs for trend confirmation
     ema_20 = EMAIndicator(close=data['close'], window=20)
     ema_50 = EMAIndicator(close=data['close'], window=50)
     ema_65 = EMAIndicator(close=data['close'], window=65)
     ema_400 = EMAIndicator(close=data['close'], window=400)
     data['ema_20'] = ema_20.ema_indicator()
     data['ema_50'] = ema_50.ema_indicator()
     data['ema_65'] = ema_65.ema_indicator()
     data['ema_400'] = ema_400.ema_indicator()
     # Calculate %K and %D
     data['%K'] = stoch.stoch()
     data['%D'] = stoch.stoch_signal()
     data['%D_DEV'] = data['%D'].rolling(window=20).std()
     data['stddev_20'] = data['close'].rolling(window=20).std()
     # Calculate Supertrend
     data = calculate_supertrend(data)
     data = calculate_dema(data)
     data['std_dema'] = data['DEMA'].rolling(window=20).std()
     data['macd'] = data['ema_12'] - data['ema_26']
     data['macd_signal'] = data['macd'].ewm(span=9, adjust=False).mean()
     adx = ADXIndicator(high=data['high'], low=data['low'], close=data['close'], window=14)
     data['adx'] = adx.adx()
     return data

def strat(data):
    d = data.copy()
    # Calculate OBV and OBV Oscillator
    data['trade_type'] = 'NONE'
    data['signals'] = 0  # 1 for buy, -1 for sell, 0 for hold
    position_opened = None
    entry_price = None
    tp=None
    sl=None
    bb_count = 0
    bb_count_short = 0
    print("Running signal generation logic")
    for i in tqdm(range(65, len(data))):  # Start after sufficient data for indicators
        # Long Entry Conditions
        if position_opened is None:
            if (
                data['close'].iloc[i] > data['ema_65'].iloc[i] > data['ema_400'].iloc[i]  # EMA confirmation
                and (
                    data['obv_osc'].iloc[i] > 0 
                    or data['supertrend_signal'].iloc[i]
                )
                and data['adx'].iloc[i] > 20
                and data['vli_fast'].iloc[i]<= data['vli_slow'].iloc[i]# Strong trend confirmation
            ):
                data['signals'].iloc[i] = 1
                data['trade_type'].iloc[i] = 'ENTRY LONG'
                position_opened = 1
                entry_price = data['close'].iloc[i]
                tp=1.2*entry_price
                sl=0.9*entry_price
                bb_count = 0  
                
            elif(data['close'][i] < (data['DEMA'][i] - 1.5*data['std_dema'][i]) ) and data['adx'].iloc[i] > 20 and data['macd'][i] < data['macd_signal'][i] and (data['%K'][i]<data['%D'][i]-2*data['%D_DEV'][i]) :
                data['signals'].iloc[i] = -1
                data['trade_type'].iloc[i] = 'ENTRY SHORT'
                position_opened = -1
                entry_price = data['close'].iloc[i]
                tp=0.8*entry_price
                sl=1.1*entry_price

        elif position_opened == -1:
            data['trade_type'].iloc[i] = 'HOLD SHORT'
            if data['close'].iloc[i] < data['bb_upper'].iloc[i]:
                bb_count_short = 0
            else:
                bb_count_short += 1
                
            if (
                data['close'].iloc[i] > data['ema_65'].iloc[i] > data['ema_400'].iloc[i]  # EMA confirmation
                and (
                    data['obv_osc'].iloc[i] > 0 
                    or data['supertrend_signal'].iloc[i]
                )
                and data['adx'].iloc[i] > 20# Strong trend confirmation
            ):
                data['signals'].iloc[i] = 2
                data['trade_type'].iloc[i] = 'EXIT SHORT and ENTRY LONG'
                position_opened = 1
                entry_price = data['close'].iloc[i]
                tp=1.2*entry_price
                sl=0.9*entry_price
                bb_count = 0
                
            elif (
               data['close'][i] > data['DEMA'][i]+ 1.5*data['std_dema'][i] or bb_count_short>=5 or abs(data['log_returns_entropy'][i]) > 5*abs(data['entropy_threshold'][i])
            ):
                data['signals'].iloc[i] = 1
                data['trade_type'].iloc[i] = 'EXIT SHORT'
                position_opened = None
                entry_price = None
                tp=None
                sl=None
         
            elif data['close'].iloc[i]>=sl:
                data['signals'].iloc[i]=1
                data['trade_type'].iloc[i] = 'EXIT SHORT'
                position_opened = None
                entry_price = None
                sl = None
                tp = None
               
            elif data['close'].iloc[i]<=tp:
                tp=0.9*data['close'].iloc[i]
                sl=1.05*data['close'].iloc[i]
                
            
        # Long Exit Conditions
        elif position_opened == 1:
            data['trade_type'].iloc[i] = 'HOLD LONG'
            if data['close'].iloc[i] > data['bb_lower'].iloc[i]:
                bb_count = 0
            else:
                bb_count += 1
            if ((data['ema_20'].iloc[i]<data['ema_50'].iloc[i] and data['ema_20'].iloc[i-1] > data['ema_50'].iloc[i-1]) or bb_count >= 5 or abs(data['log_returns_entropy'][i]) > 5*abs(data['entropy_threshold'][i])):
                data['signals'].iloc[i] = -1
                data['trade_type'].iloc[i] = 'EXIT LONG'
                position_opened = None
                entry_price = None
                tp=None
                bb_count = 0
               
            elif data['close'].iloc[i]<=sl:
                data['signals'].iloc[i]=-1
                data['trade_type'].iloc[i] = 'EXIT LONG'
                position_opened = None
                entry_price = None
                sl = None
                tp = None
            elif data['close'].iloc[i]>=tp:
                tp=1.1*data['close'].iloc[i]
                sl=0.9*data['close'].iloc[i]
            
    d['signals'] = data['signals']
    d['trade_type'] = data['trade_type']
    data = d
    return data

def main():
     data = pd.read_csv("ETHUSDT_1h.csv")
     processed_data = process_data(data)
     result_data = strat(processed_data)
     csv_file_path = "resultsETH.csv"
     result_data = result_data[['datetime', 'close', 'open', 'high', 'low', 'trade_type', 'signals']]
     result_data.to_csv(csv_file_path, index=False)
     print(result_data['signals'].value_counts())
     backtest_result = perform_backtest(csv_file_path)
     print(backtest_result)
     # No need to use following code if you are using perform_backtest_large_csv
     for value in backtest_result:
         print(value)


if __name__ == "__main__":
     main()



