import numpy as np
import pandas as pd
import warnings
from scipy.signal import butter, filtfilt
from scipy.stats import entropy
from hurst import compute_Hc
from tqdm import tqdm
import pywt
import ta
import uuid
import os

warnings.filterwarnings("ignore")

# ## Untrade backtesting script
from untrade.client import Client
from pprint import pprint

def perform_backtest_large_csv(csv_file_path):
     client = Client()
     file_id = str(uuid.uuid4())
     chunk_size = 90 * 1024 * 1024
     total_size = os.path.getsize(csv_file_path)
     total_chunks = (total_size + chunk_size - 1) // chunk_size
     chunk_number = 0
     if total_size <= chunk_size:
         total_chunks = 1
         # Normal Backtest
         result = client.backtest(
             file_path=csv_file_path,
             leverage=1,
             jupyter_id="Team22_Zelta_HPPS",
             # result_type="Q",
         )
         for value in result:
             print(value)

         return result

     with open(csv_file_path, "rb") as f:
         while True:
             chunk_data = f.read(chunk_size)
             if not chunk_data:
                 break
             chunk_file_path = f"/tmp/{file_id}_chunk_{chunk_number}.csv"
             with open(chunk_file_path, "wb") as chunk_file:
                 chunk_file.write(chunk_data)

             # Large CSV Backtest
             result = client.backtest(
                 file_path=chunk_file_path,
                 leverage=1,
                 jupyter_id="Team22_Zelta_HPPS",
                 file_id=file_id,
                 chunk_number=chunk_number,
                 total_chunks=total_chunks,
                 # result_type="Q",
             )

             for value in result:
                 print(value)

             os.remove(chunk_file_path)

             chunk_number += 1

     return result

def perform_backtest(csv_file_path, type=None):
    """
    Perform backtesting using the untrade SDK.

    Parameters:
    - csv_file_path (str): Path to the CSV file containing historical price data and signals.
    - type: type of result

    Returns:
    - result (generator): Result is a generator object that can be iterated over to get the backtest results.
    """
    # Create an instance of the untrade client
    client = Client()

    if type is not None:
    # Perform backtest using the provided CSV file path
        result = client.backtest(
            file_path=csv_file_path,
            leverage=1,  # Adjust leverage as needed
            jupyter_id="Team22_Zelta_HPPS",  # the one you use to login to jupyter.untrade.io
            result_type=type
        )

    else:
        result = client.backtest(
            file_path=csv_file_path,
            leverage=1,  # Adjust leverage as needed
            jupyter_id="Team22_Zelta_HPPS",  # the one you use to login to jupyter.untrade.io
        )

    for i in result:
        print(i)
    return result


##############################################################################################################################################
# INDICATOR CALCULATION FUNCTIONS 
# START
def calculate_dema(df, column='close', window=20):
    # Calculate the first EMA
    ema1 = df[column].ewm(span=window, adjust=False).mean()
    # Calculate the second EMA on the first EMA
    ema2 = ema1.ewm(span=window, adjust=False).mean()
    # Calculate DEMA
    df['DEMA'] = 2 * ema1 - ema2
    return df

def sl_std(std,close,long):
    if long:
        if std>0.4:
            return 0.95*close
        else:
            return 0.97*close
    else:
        if std>0.4:
            return 1.05*close
        else:
            return 1.03*close
        
def calculate_entropy(series, bins=10):
    # Drop any NaN values
    series = series.dropna()
    # Create histogram of the series (volume in this case)
    _, bin_edges = np.histogram(series, bins=bins)
    # Calculate the probability distribution
    counts, _ = np.histogram(series, bins=bin_edges)
    probabilities = counts / len(series)
    # Apply Shannon entropy formula
    entropy = -np.sum(probabilities * np.log(probabilities + 1e-9))  # Add small epsilon to prevent log(0)
    return entropy

def limit_closing(close_curr, close_prev,long):
    if long:
        if (close_prev-close_curr)/close_curr >=0.07:
            return True
    else:
        if (close_curr-close_prev)/close_curr >=0.07:
            return True
        
def price_change_limit(close,high,low,long):
    if long:
       if  (close-low)/close >=0.07:
           return True
    else:
        if  (high-close)/close >=0.07:
           return True
        
def calculate_heikin_ashi(df):
    df['ha_close'] = (df['open'] + df['high'] + df['low'] + df['close']) / 4
    df['ha_open'] = (df['open'].shift(1) + df['close'].shift(1)) / 2
    df['ha_high'] = df[['ha_open', 'ha_close', 'high']].max(axis=1)
    df['ha_low'] = df[['ha_open', 'ha_close', 'low']].min(axis=1)

def calculate_entropy(series):
    # Remove NaN values from the series
    series = series.dropna()
    # Calculate the histogram and probabilities of log returns
    _, bin_edges = np.histogram(series, bins=10)
    probabilities = np.diff(np.histogram(series, bins=bin_edges)[0]) / len(series)
    # Calculate Shannon Entropy
    entropy = -np.sum(probabilities * np.log(probabilities + 1e-9))  # Added small value to prevent log(0)
    return entropy

def calculate_Information_ratio_exponent(data, window=10):
    if len(data) < window:
        return np.nan

    # Convert to numpy array
    x = np.array(data)

    # Calculate log returns
    returns = np.log(x[1:] / x[:-1])

    # Compute mean and standard deviation of returns
    mean_return = np.mean(returns)
    std_return = np.std(returns)

    # Information_ratio exponent estimation
    Information_ratio = mean_return / std_return if std_return != 0 else 0

    return Information_ratio

def compute_daily_Information_ratio_exponents(df, column='close', window=10):
    Information_ratio_series = []

    for i in range(window, len(df) + 1):
        subset = df[column].iloc[i-window:i]
        lyap = calculate_Information_ratio_exponent(subset, window)
        Information_ratio_series.append(lyap)

    # Pad beginning with NaNs
    Information_ratio_series = [np.nan] * (window - 1) + Information_ratio_series

    return pd.Series(Information_ratio_series, index=df.index)

def hurst_exponent(df):
    print("Computing Hurst Exponent")
    random_walk = df['close']
    # Calculate Hurst exponent manually for full series
    # Rolling Hurst calculation
    window = 100
    arr=[]
    arr.extend([np.nan] * (window - 1))  
    for i in tqdm(range(len(random_walk) - window + 1)):
        arr.append(compute_Hc(random_walk[i:i+window], kind='random_walk')[0])  
    df['Hurst'] = arr

def wavelet_entropy(coeffs):
    # Flatten the wavelet coefficients for entropy calculation
    coeffs_flat = np.hstack([c.flatten() for c in coeffs if c is not None])
    # Calculate the probability distribution of the wavelet coefficients
    hist, bin_edges = np.histogram(coeffs_flat, bins=50, density=True)
    # Avoid zero probability values for log calculation
    hist = hist[hist > 0]
    # Calculate entropy using Shannon entropy formula
    return entropy(hist)

# Function to calculate Wavelet Transform Entropy for each day
def calculate_wte(df, wavelet='db4', level=4):
    wte_values = []
    print("Computing WTE")
    for i in tqdm(range(1, len(df))):
        # Select the volume data up to day i
        data = df['volume'][:i]
        # Perform wavelet decomposition on the data up to day i
        coeffs = pywt.wavedec(data, wavelet, level=level)
        # Calculate the wavelet entropy for the decomposed coefficients
        wte = wavelet_entropy(coeffs)
        # Append the calculated WTE
        wte_values.append(wte)

    # Return a list of WTE values along with the corresponding dates
    wte_df = pd.DataFrame({
        'date': df['datetime'][1:],  # Skip the first day as there's no previous data
        'wte': wte_values
    })
    df['wte']= wte_df['wte']
    return df

# Define low-pass filter function
def butter_lowpass_filter(data, cutoff, fs, order=5):
    nyquist = 0.5 * fs
    normal_cutoff = cutoff / nyquist
    b, a = butter(order, normal_cutoff, btype='low', analog=False)
    y = filtfilt(b, a, data)
    return y

# Incremental filtering logic with delayed signal generation
def incremental_smoothing(df, cutoff, fs, order=5):
    print("Computing smooth close values")
    smooth = []
    for i in tqdm(range(0, len(df))):
        if (i<15):
            smooth.append(0)
            continue
        past_data = df.iloc[:i+1]
        cs = butter_lowpass_filter(past_data['close'], cutoff, fs, order)
        smooth.append(cs[-1])
    df['smoothed'] = smooth

# INDICATOR Methods END
#######################################################################################################################################
def process_data(df):
     """
     Process the input data and return a dataframe with all the necessary indicators and data for making signals.

     Parameters:
     data (pandas.DataFrame): The input data to be processed.

     Returns:
     pandas.DataFrame: The processed dataframe with all the necessary indicators and data.
     """
     df = calculate_wte(df)
     calculate_heikin_ashi(df)
     incremental_smoothing(df, 0.01, 1, 3)
     hurst_exponent(df)
     df['ha_open'][0]=df['open'][0]
     df['VWAP'] = ta.volume.volume_weighted_average_price(df['high'], df['low'], df['close'], df['volume'])
     df['VWAP_std_dev'] = df['VWAP'].rolling(2).std() * 3
     df['VWAP_mean'] = df['VWAP'].rolling(2).mean()
     df['SMA15'] = ta.trend.SMAIndicator(close=df['close'], window=15).sma_indicator()
     df['SMA'] = ta.trend.SMAIndicator(close=df['close'], window=50).sma_indicator()
     df['EMA'] = ta.trend.EMAIndicator(close=df['close'], window=20).ema_indicator()
     df['SMA200'] = ta.trend.SMAIndicator(close=df['close'], window=200).sma_indicator()
     df['EMA_short'] = ta.trend.EMAIndicator(close=df['close'], window=100).ema_indicator()
     df['ADX'] = ta.trend.ADXIndicator(df['high'], df['low'], df['close'], window = 30).adx()
     df['log_returns'] = np.log(df['close'] / df['close'].shift(1))
     df['entropy'] = df['log_returns'].rolling(window=14).apply(calculate_entropy, raw=False)
     df['entropy_threshold'] = df['entropy'].rolling(window=14).mean().quantile(0.85)
     df['volume_entropy'] = df['volume'].rolling(window=14).apply(calculate_entropy, raw=False)
     stoch = ta.momentum.StochasticOscillator(
         high=df['high'],
         low=df['low'],
         close=df['close'],
         window=14,         # Window for %K (typically 14)
         smooth_window=3    # Window for %D (typically 3)
     )
     df['%K'] = stoch.stoch()
     df['%D'] = stoch.stoch_signal()
     df['rsi']=ta.momentum.rsi(df['close'], window=20, fillna=False) 
     df['adv15'] = df['volume'].rolling(15).mean() 
     df['adv20'] = df['volume'].rolling(20).mean() 
     df['Hurstm'] = df['Hurst'].rolling(30).mean()
     df['Information_ratio'] = compute_daily_Information_ratio_exponents(df)
     df['ds_dt'] = df["smoothed"].diff()
     df['ds_dt_slow'] = df["ds_dt"].rolling(3).mean()
     df['ds_dt_fast'] = df["ds_dt"].rolling(12).mean()
     df['std']=(df['close'].rolling(window=20).std()/df['close'])*100
     return df

def strat(df):    
    d = df.copy()
    position = None
    signals = []
    position = None
    curval = None
    sl=None
    longwins=0
    shortwins=0
    tp=None
    cooldown=0
    df['trade_type'] = ['NONE']*len(df)
    print("Running signal generation logic")
    for i in tqdm(range(len(df))):
        if(i<=336):
            signals.append(0)
            continue
        if position is None:
            #Short entry condition
             if ((df['close'][i] >= df['VWAP_mean'][i] + df['VWAP_std_dev'][i]) and \
                  (df['SMA'][i] < df['SMA200'][i])  and (df['EMA'][i] < df['SMA'][i])  and df['volume'][i]>df['adv15'][i] and df['ADX'][i] > 25 
                 or df['Information_ratio'][i]>1.5   and df['Hurst'][i]<df['Hurstm'][i]
                ) :
                 df['trade_type'][i]='Entry Short'
                 curval = df['close'][i]
                 signals.append(-1)
                 tp=0.9*curval
                 position = -1
                 sl=sl_std(df['std'][i],df['close'][i],False)

            # Long entry condition
             elif  ((df['volume'][i]>1.25*df['adv20'][i]
                   and df["rsi"][i]>60 and  df['%K'][i]>df['%D'][i] and df['close'][i]>df['EMA_short'][i]
                   and  df['ha_open'][i]<df['ha_close'][i] 
                  )) :
                df['trade_type'][i]='Entry Long'
                signals.append(1)  # Buy signal
                position = 1
                curval = df['close'][i]
                tp=1.1*curval
                sl=sl_std(df['std'][i],df['close'][i],True)
             else:
                signals.append(0)

        elif position == 1:
            if(longwins==2 and cooldown):
                temptp=tp/2
                tempsl=sl/2
            elif longwins>=3 and cooldown:
                temptp=tp/4
                sl=sl/4
            else :
                temptp=tp
                tempsl=sl

            # Long exit condition
            if((df['close'][i] >= temptp) or (df['close'][i] <= tempsl) or df['entropy'][i] > df['entropy_threshold'][i]  or df['wte'][i]>1.85 
               or limit_closing(df['high'][i],df['close'][i-1],True) or (df['Information_ratio'][i]>1.85) and df['Hurst'][i]<.3
              ):
                if(df['close'][i]>curval):
                    longwins+=1
                    shortwins=0
                    cooldown=20
                else :
                    shortwins=0
                    longwins=0
                
                position = None
                signals.append(-1) 
                df['trade_type'][i] = 'Exit Long'
            else:
                signals.append(0)
                df['trade_type'][i] = 'Hold Long'

        elif position == -1:
            if(shortwins==2 and cooldown):
                temptp=tp/2
                tempsl=sl/2
            elif shortwins>=3 and cooldown:
                temptp=tp/4
                sl=sl/4
            else :
                temptp=tp
                tempsl=sl
            
            #Short Exit
            if ((df['close'][i] >= sl) or (df['close'][i] <= tp) or df['entropy'][i] > df['entropy_threshold'][i] or df['wte'][i]<1.15 
                or limit_closing(df['close'][i],df['close'][i-1],False) and df['Hurst'][i]<.3
               ) or ((df['SMA15'][i] > df['smoothed'][i]) and (df['SMA15'][i-1] <= df['smoothed'][i-1]) and (df['ds_dt_slow'][i]>df['ds_dt_fast'][i]) and (df['ADX'][i] >= 50)):
                if(df['close'][i]<curval):
                    shortwins+=1
                    longwins=0
                    cooldown=20
                else :
                    shortwins=0
                    longwins=0
                position = None
                signals.append(1)   
                df['trade_type'][i] = 'Exit Short'
            else:
                df['trade_type'][i] = 'Hold Short'
                signals.append(0)
        else:
            signals.append(0)

    df["signals"] = signals
    return df

def main():
     data = pd.read_csv("BTC_2019_2023_30m.csv")
     processed_data = process_data(data)
     result_data = strat(processed_data)
     result_data = result_data[['datetime', 'open', 'high', 'low', 'close', 'volume', 'trade_type']]
     csv_file_path = "resultsBTC.csv"
     result_data.to_csv(csv_file_path, index=False)
     print(result_data['signals'].value_counts())
     backtest_result = perform_backtest(csv_file_path)
     # No need to use following code if you are using perform_backtest_large_csv
     print(backtest_result)
     for value in backtest_result:
         print(value)

if __name__ == "__main__":
     main()



